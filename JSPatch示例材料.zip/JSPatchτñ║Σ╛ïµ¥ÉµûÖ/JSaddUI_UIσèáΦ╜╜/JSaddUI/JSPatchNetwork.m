//
//  JSPatchNetwork.m
//  JSaddUI
//
//  Created by evelyn on 16/5/18.
//  Copyright © 2016年 evelyn. All rights reserved.
//

#import "JSPatchNetwork.h"

@implementation JSPatchNetwork

- (void)orderNetWorkBlock:(NSMutableDictionary *)dict callBack:(handCompleteBlock)block{
    
}

@end
