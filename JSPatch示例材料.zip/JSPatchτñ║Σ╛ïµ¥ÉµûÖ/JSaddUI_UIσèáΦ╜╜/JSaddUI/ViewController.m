//
//  ViewController.m
//  JSaddUI
//
//  Created by evelyn on 16/5/17.
//  Copyright © 2016年 evelyn. All rights reserved.
//

#import "ViewController.h"
#import "JSPatchNetwork.h"

@interface ViewController ()

@property(nonatomic,strong) NSArray *orderList;
@property(nonatomic,strong) UITableView *customTableView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)orderNetWorkBlock{
    NSMutableDictionary *tempParams = [NSMutableDictionary dictionary];
    [tempParams setValue:@"1" forKey:@"pageNo"];
    [tempParams setValue:@"5" forKey:@"pageRange"];
    [tempParams setValue:@"1" forKey:@"payFlag"];
 
    JSPatchNetwork *patchNetwork = [[JSPatchNetwork alloc]init];
    [patchNetwork orderNetWorkBlock:tempParams callBack:^(id successInfo, id errorInfo) {
        
        if (errorInfo) {
            NSLog(@"---------网络请求失败---------");
        }else{
            self.orderList = successInfo;
            [self.customTableView reloadData];
        }
    }];
}

@end
