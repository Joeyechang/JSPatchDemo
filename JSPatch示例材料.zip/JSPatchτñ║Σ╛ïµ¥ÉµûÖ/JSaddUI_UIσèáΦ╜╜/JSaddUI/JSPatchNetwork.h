//
//  JSPatchNetwork.h
//  JSaddUI
//
//  Created by evelyn on 16/5/18.
//  Copyright © 2016年 evelyn. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^handCompleteBlock)(id successInfo,id errorInfo);

@interface JSPatchNetwork : NSObject

- (void)orderNetWorkBlock:(NSMutableDictionary *)dict callBack:(handCompleteBlock)block;

@end
