
require('UIColor,UILabel,UIFont,UIButton')
require('ViewController')
defineClass("ViewController",{

	viewDidLoad:function () {
		self.super().viewDidLoad()
            
        self.setTitle("订单列表")
        self.initUI()
        
	},
    initUI:function(){
            
        var labelNo = UILabel.alloc().initWithFrame({x:58, y:100, width:100, height:35})
        labelNo.setText("订单号")
        labelNo.setFont(UIFont.fontWithName_size("Helvetica",16))
        labelNo.setBackgroundColor(UIColor.redColor())
        self.view().addSubview(labelNo)
            
        var button = UIButton.alloc().initWithFrame({x:58, y:300, width:100, height:35})
        button.setBackgroundColor(UIColor.blueColor())
        self.view().addSubview(button)
    }

});