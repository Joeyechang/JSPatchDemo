//
//  OrderInfo.h
//  JS_TableView列表实现0511
//
//  Created by evelyn on 16/5/11.
//  Copyright © 2016年 evelyn. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OrderInfo : NSObject

@end
