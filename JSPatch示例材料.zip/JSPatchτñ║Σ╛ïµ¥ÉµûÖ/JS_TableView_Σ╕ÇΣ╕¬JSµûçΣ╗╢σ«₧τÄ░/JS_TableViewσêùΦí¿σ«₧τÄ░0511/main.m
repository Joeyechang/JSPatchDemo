//
//  main.m
//  JS_TableView列表实现0511
//
//  Created by evelyn on 16/5/11.
//  Copyright © 2016年 evelyn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
