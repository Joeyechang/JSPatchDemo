//
//  OrderTableViewCell.m
//  JS_TableView列表实现0511
//
//  Created by evelyn on 16/5/11.
//  Copyright © 2016年 evelyn. All rights reserved.
//

#import "OrderTableViewCell.h"

@implementation OrderTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
