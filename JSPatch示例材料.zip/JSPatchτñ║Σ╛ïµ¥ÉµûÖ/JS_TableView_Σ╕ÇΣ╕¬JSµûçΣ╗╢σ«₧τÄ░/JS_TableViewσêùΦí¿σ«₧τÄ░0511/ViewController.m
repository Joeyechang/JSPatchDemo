//
//  ViewController.m
//  JS_TableView列表实现0511
//
//  Created by evelyn on 16/5/11.
//  Copyright © 2016年 evelyn. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
//    self.navigationItem.title = @"订单列表";
    
    //         // self.orderTableView.getDelegate = self;

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
