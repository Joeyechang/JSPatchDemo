
/****** 头文件的导入 ********/
require('NSArray,NSBundle,NSDictionary,NSMutableArray')
/*UIKit*/
require('UIColor,UITableView,UIViewController,UITableViewCell,UIScreen,UIFont')
require('OrderInfo,OrderTableViewCell')

/****** MyViewController类 ********/
defineClass("ViewController:UIViewController<UITableViewDataSource,UITableViewDelegate>",["customTableView","orderList"],{

/****** 获取本地文件数据 ********/
  getOrderList:function(){
    // console.log("1-----------------")
    if (self.orderList() == null) {
 
       var file = NSBundle.mainBundle().pathForResource_ofType("spring100","plist")
       var dict = NSDictionary.dictionaryWithContentsOfFile(file)

       console.log(dict.valueForKey("orders").count())

       var tempList = NSMutableArray.array()
       for (var i = 0; i < dict.valueForKey("orders").count(); i++) {
             var order = OrderInfo.alloc().initwithDict(dict.valueForKey("orders").objectAtIndex(i))
             tempList.addObject(order)
       };
       self.setOrderList(tempList)
       console.log(self.orderList())
    };   
  },
            
	viewDidLoad:function() { 
      self.super().viewDidLoad();

      self.setTitle("订单列表")

      self.view().setBackgroundColor(UIColor.orangeColor())
      self.setEdgesForExtendedLayout(0)
      
      var windowWidth = UIScreen.mainScreen().bounds().width
      var windowHeight = UIScreen.mainScreen().bounds().height
      var orderTableView = UITableView.alloc().initWithFrame_style({x:0, y:0, width:windowWidth, height:windowHeight-64},0)

      self.setCustomTableView(orderTableView)
       
      self.customTableView().setDelegate(self)
      self.customTableView().setDataSource(self)

      self.view().addSubview(self.customTableView());

      self.getOrderList()

   },

/****** UITableView协议方法的实现 ********/
   tableView_numberOfRowsInSection:function(tableView,section){
   	  // return UIFont.familyNames().count();
      return self.orderList().count()
   },

   tableView_cellForRowAtIndexPath:function(tableView,indexPath){

      var identify = "identify"
      var cell = tableView.dequeueReusableCellWithIdentifier(identify)
      if (!cell) {
         cell = OrderTableViewCell.alloc().initWithStyle_reuseIdentifier(3,identify)
      };

      var fontStr = self.orderList().objectAtIndex(indexPath.row())
      cell.ordersWithData(fontStr);
            
      return cell;
   },

  tableView_heightForRowAtIndexPath: function(tableView, indexPath) {
    return 120
  },

  tableView_didSelectRowAtIndexPath: function(tableView, indexPath) {
        var fontStr = self.orderList().objectAtIndex(indexPath.row())
        console.log(fontStr)
  },

});

/****** OrderTableViewCell类 ********/
require('UILabel,UIImageView,UIImage,UITableView')
require('OrderTableViewCell')
defineClass("OrderTableViewCell",["city","num","timeText","money","pay"],{
            
/****** 初始化UI ********/
  initWithStyle_reuseIdentifier:function(style,reuseIdentifier) {

    self = self.super().initWithStyle_reuseIdentifier(style,reuseIdentifier)
    if (self) {
      var windowWidth = UIScreen.mainScreen().bounds().width
      var windowHeight = UIScreen.mainScreen().bounds().height

      var labelNo = UILabel.alloc().initWithFrame({x:58, y:29, width:51, height:21})
      labelNo.setText("订单号")
      labelNo.setFont(UIFont.fontWithName_size("Helvetica",12))
      self.contentView().addSubview(labelNo)

      var labelTime = UILabel.alloc().initWithFrame({x:45, y:58, width:51, height:21})
      labelTime.setText("预定时间")
      labelTime.setFont(UIFont.fontWithName_size("Helvetica",12))
      self.contentView().addSubview(labelTime)

      var labelMoney = UILabel.alloc().initWithFrame({x:45, y:87, width:51, height:21})
      labelMoney.setText("订单金额")
      labelMoney.setFont(UIFont.fontWithName_size("Helvetica",12))
      self.contentView().addSubview(labelMoney)

      var img = UIImageView.alloc().initWithFrame({x:330, y:53, width:10, height:30})
      img.setImage(UIImage.imageNamed("arrow_right_v600"))
      self.contentView().addSubview(img)

      var c = UILabel.alloc().initWithFrame({x:0, y:0, width:windowWidth, height:21})
      c.setBackgroundColor(UIColor.grayColor())
      c.setFont(UIFont.boldSystemFontOfSize(14.0))//加粗字体及大小
      c.setTextAlignment(1)//居中
      self.setCity(c)
      self.contentView().addSubview(self.city())

      var n = UILabel.alloc().initWithFrame({x:111, y:29, width:93, height:21})
      n.setFont(UIFont.fontWithName_size("Helvetica",12))
      self.setNum(n)
      self.contentView().addSubview(self.num())

      var t = UILabel.alloc().initWithFrame({x:111, y:58, width:134, height:21})
      t.setFont(UIFont.fontWithName_size("Helvetica",12))
      self.setTimeText(t)
      self.contentView().addSubview(self.timeText())

      var m = UILabel.alloc().initWithFrame({x:111, y:87, width:61, height:21})
      m.setTextColor(UIColor.redColor())
      m.setFont(UIFont.fontWithName_size("Helvetica",12))
      self.setMoney(m)
      self.contentView().addSubview(self.money())

      var p = UILabel.alloc().initWithFrame({x:280, y:58, width:60, height:21})
      p.setFont(UIFont.fontWithName_size("Helvetica",12))
      self.setPay(p)
      self.contentView().addSubview(self.pay())

    };
    return self
  },

/****** 数据实现 ********/
  ordersWithData:function(data){
    var ord = OrderInfo.alloc().init()
    ord = data
    console.log(ord)

    self.city().setText(ord.originDestCity())
    self.num().setText(ord.orderNo())
    self.timeText().setText(ord.orderDate())
    self.money().setText(ord.orderMoneyDisplay())
    self.pay().setText(ord.orderStatusDescript())

  }
});

/****** OrderInfo模型类 ********/
require('NSString')
defineClass("OrderInfo",["orderDate","orderMoneyDisplay","orderNo","orderStatusDescript","originDestCity"],{
  initwithDict:function(dict){

        if(self = self.super().init()){

        self.setOrderNo(dict.valueForKey("orderNo"))
        self.setOrderDate(dict.valueForKey("orderDate"))
        self.setOrderMoneyDisplay(dict.valueForKey("orderMoneyDisplay"))
        self.setOrderStatusDescript(dict.valueForKey("orderStatusDescript"))
        self.setOriginDestCity(dict.valueForKey("originDestCity"))
     }
    return self
  },
  ordersModelWithDict:function(dict){
    return self.alloc().initwithDict(dict)
  }

});





































