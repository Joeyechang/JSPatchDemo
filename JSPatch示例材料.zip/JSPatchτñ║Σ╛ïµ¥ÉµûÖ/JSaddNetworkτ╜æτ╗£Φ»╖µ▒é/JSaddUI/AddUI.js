
require('UIColor,UILabel,UIFont,UIButton,UIImageView,UIImage,NSURL,NSMutableURLRequest,NSURLSession')
require('NSData,NSURLResponse,NSError,NSURLSessionDataTask')
require('ViewController')
defineClass("ViewController",["imageView"],{

	viewDidLoad:function () {
		self.super().viewDidLoad()
            
        self.setTitle("订单列表")
        self.initUI()
        
	},
    initUI:function(){
            
        var labelNo = UILabel.alloc().initWithFrame({x:58, y:100, width:100, height:35})
        labelNo.setText("订单号")
        labelNo.setFont(UIFont.fontWithName_size("Helvetica",16))
        labelNo.setBackgroundColor(UIColor.redColor())
        self.view().addSubview(labelNo)
            
        var button = UIButton.alloc().initWithFrame({x:58, y:300, width:100, height:35})
        button.setBackgroundColor(UIColor.blueColor())
        self.view().addSubview(button)
        button.addTarget_action_forControlEvents(self,"btnClick:",5)

        var imgView = UIImageView.alloc().initWithFrame({x:58, y:400, width:300, height:200})
        imgView.setBackgroundColor(UIColor.yellowColor())
        self.setImageView(imgView)

        self.view().addSubview(self.imageView())
    },
    btnClick:function(sender){
    
        console.log("---------------------")
        self.requestNetwork()

    },
/********* 网络请求 ************/
    requestNetwork:function(){
      
     var url = NSURL.URLWithString("http://pic34.nipic.com/20131101/6608733_203319653000_2.jpg")
      var request = NSMutableURLRequest.requestWithURL(url)

      var session = NSURLSession.sharedSession()
      
      var tempSelf = self
      var task = NSURLSessionDataTask.alloc().init()
      task = session.dataTaskWithRequest_completionHandler(request,block("NSData *,NSURLResponse *,NSError *",function(data,response,error){
        if (error) {
            console.log("连接失败");
            return;
        }
        console.log("+++++++++++++++++++++++") 
        console.log(data)                                                           
        var image = UIImage.imageWithData(data)
        console.log("####################") 
        console.log(image)                                                                
        tempSelf.imageView().setImage(image)
      }));

      task.resume()

    },

});