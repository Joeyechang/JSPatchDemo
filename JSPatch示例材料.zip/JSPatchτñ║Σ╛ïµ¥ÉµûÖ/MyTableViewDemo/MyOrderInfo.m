//
//  OrderInfo.m
//  JS_TableView列表实现0511
//
//  Created by evelyn on 16/5/11.
//  Copyright © 2016年 evelyn. All rights reserved.
//

#import "MyOrderInfo.h"

@implementation MyOrderInfo

@end
