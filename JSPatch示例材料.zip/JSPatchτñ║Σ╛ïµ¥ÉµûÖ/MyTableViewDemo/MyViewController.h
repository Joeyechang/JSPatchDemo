//
//  MyViewController.h
//  Spring3G
//
//  Created by evelyn on 16/5/13.
//  Copyright © 2016年 SpringAirlines. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyViewController : MyNavigationViewController

@end
