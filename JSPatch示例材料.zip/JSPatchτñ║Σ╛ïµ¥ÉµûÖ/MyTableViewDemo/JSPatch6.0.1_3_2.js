



/****** 头文件的导入 ********/
require('NSArray,NSBundle,NSDictionary,NSMutableArray,NSNumber,BOOL,NSBlock')
/*UIKit*/
require('UIColor,UITableView,UIViewController,UITableViewCell,UIScreen,UIFont')
require('MyOrderInfo,OrderTableViewCell')

/****** 全局属性的定义 ********/
var viewController = null

/****** block的定义 ********/
function getOrderListBlock(successInfo, errorInfo){
      console.log("回调结果:")   
      console.log(successInfo)

      var successInfoDict = NSDictionary.dictionary()
      successInfoDict = successInfo

      var ifSuccess = successInfoDict.valueForKey("ifSuccess")
      if (ifSuccess.isEqualToString("Y")) {

        var tempArray = NSMutableArray.array()
        for (var i = 0; i < successInfoDict.valueForKey("orders").count(); i++) {
               var order = MyOrderInfo.alloc().initWithDictionary(successInfoDict.valueForKey("orders").objectAtIndex(i))
               tempArray.addObject(order)
         };
         viewController.reloadOrderList(tempArray)
      };

}

/****** MyViewController类 ********/
defineClass("MyViewController:UIViewController<UITableViewDataSource,UITableViewDelegate>",["customTableView","orderList"],{

  reloadOrderList:function(data){

    console.log("+++++++++++++++++++++++++++++++++++++++++++++++++++++")
    console.log(data)

    self.setOrderList(data)

    self.customTableView().reloadData()
  },

	viewDidLoad:function() { 
      self.super().viewDidLoad();

      self.setTitle("订单列表")

      viewController = self;
            
      self.view().setBackgroundColor(UIColor.orangeColor())
      self.setEdgesForExtendedLayout(0)
      
      var windowWidth = UIScreen.mainScreen().bounds().width
      var windowHeight = UIScreen.mainScreen().bounds().height
      var orderTableView = UITableView.alloc().initWithFrame_style({x:0, y:0, width:windowWidth, height:windowHeight-64},0)

      self.setCustomTableView(orderTableView)
            
      self.customTableView().setDelegate(self)
      self.customTableView().setDataSource(self)

      self.view().addSubview(self.customTableView());

      self.setOrderList(NSArray.array())

      var o = MyOrderInfo.alloc().init()
      o.orderNetWorkBlock(getOrderListBlock)    
   },

/****** UITableView协议方法的实现 ********/
   tableView_numberOfRowsInSection:function(tableView,section){
      return self.orderList().count()
   },

   tableView_cellForRowAtIndexPath:function(tableView,indexPath){

      var identify = "identify"
      var cell = tableView.dequeueReusableCellWithIdentifier(identify)
      if (!cell) {
         cell = OrderTableViewCell.alloc().initWithStyle_reuseIdentifier(3,identify)
      };

      var fontStr = self.orderList().objectAtIndex(indexPath.row())
      cell.ordersWithData(fontStr);

      return cell;
   },

  tableView_heightForRowAtIndexPath: function(tableView, indexPath) {
    return 120
  },

  tableView_didSelectRowAtIndexPath: function(tableView, indexPath) {
        var fontStr = self.orderList().objectAtIndex(indexPath.row())
        console.log(fontStr)
  },

});

/****** OrderTableViewCell类 ********/
require('UILabel,UIImageView,UIImage,UITableView')
require('OrderTableViewCell')
defineClass("OrderTableViewCell",["city","num","timeText","money","pay"],{

/****** 初始化UI ********/
  initWithStyle_reuseIdentifier:function(style,reuseIdentifier) {

    self = self.super().initWithStyle_reuseIdentifier(style,reuseIdentifier)
    if (self) {
      var windowWidth = UIScreen.mainScreen().bounds().width
      var windowHeight = UIScreen.mainScreen().bounds().height

      var labelNo = UILabel.alloc().initWithFrame({x:58, y:29, width:51, height:21})
      labelNo.setText("订单号")
      labelNo.setFont(UIFont.fontWithName_size("Helvetica",12))
      self.contentView().addSubview(labelNo)

      var labelTime = UILabel.alloc().initWithFrame({x:45, y:58, width:51, height:21})
      labelTime.setText("预定时间")
      labelTime.setFont(UIFont.fontWithName_size("Helvetica",12))
      self.contentView().addSubview(labelTime)

      var labelMoney = UILabel.alloc().initWithFrame({x:45, y:87, width:51, height:21})
      labelMoney.setText("订单金额")
      labelMoney.setFont(UIFont.fontWithName_size("Helvetica",12))
      self.contentView().addSubview(labelMoney)

      var img = UIImageView.alloc().initWithFrame({x:330, y:53, width:10, height:30})
      img.setImage(UIImage.imageNamed("arrow_right_v600"))
      self.contentView().addSubview(img)

      var c = UILabel.alloc().initWithFrame({x:0, y:0, width:windowWidth, height:21})
      c.setBackgroundColor(UIColor.grayColor())
      c.setFont(UIFont.boldSystemFontOfSize(14.0))//加粗字体及大小
      c.setTextAlignment(1)//居中
      self.setCity(c)
      self.contentView().addSubview(self.city())

      var n = UILabel.alloc().initWithFrame({x:111, y:29, width:93, height:21})
      n.setFont(UIFont.fontWithName_size("Helvetica",12))
      self.setNum(n)
      self.contentView().addSubview(self.num())

      var t = UILabel.alloc().initWithFrame({x:111, y:58, width:134, height:21})
      t.setFont(UIFont.fontWithName_size("Helvetica",12))
      self.setTimeText(t)
      self.contentView().addSubview(self.timeText())

      var m = UILabel.alloc().initWithFrame({x:111, y:87, width:61, height:21})
      m.setTextColor(UIColor.redColor())
      m.setFont(UIFont.fontWithName_size("Helvetica",12))
      self.setMoney(m)
      self.contentView().addSubview(self.money())

      var p = UILabel.alloc().initWithFrame({x:280, y:58, width:60, height:21})
      p.setFont(UIFont.fontWithName_size("Helvetica",12))
      self.setPay(p)
      self.contentView().addSubview(self.pay())

    };
    return self
  },

/****** 数据实现 ********/
  ordersWithData:function(data){
    var ord = MyOrderInfo.alloc().init()
    ord = data

    self.city().setText(ord.originDestCity())
    self.num().setText(ord.orderNo())
    self.timeText().setText(ord.orderDate())
    self.money().setText(ord.orderMoneyDisplay())
    self.pay().setText(ord.orderStatusDescript())

  }
});

/****** MyOrderInfo类 ********/
require('NSString,NSMutableDictionary')
require('CHNetworkArguments,CHCommonNetworkEngine,CHCompleteHanderBlock')
defineClass("MyOrderInfo",["orderDate","orderMoneyDisplay","orderNo","orderStatusDescript","originDestCity"],{
  initWithDictionary:function(dict){

        if(self = self.super().init()){

        self.setOrderNo(dict.valueForKey("orderNo"))
        self.setOrderDate(dict.valueForKey("orderDate"))
        self.setOrderMoneyDisplay(dict.valueForKey("orderMoneyDisplay"))
        self.setOrderStatusDescript(dict.valueForKey("orderStatusDescript"))
        self.setOriginDestCity(dict.valueForKey("originDestCity"))
     }
    return self
  },
  ordersModelWithDict:function(dict){
    return self.alloc().initWithDictionary(dict)
  },

/****** 网络请求的实现 ********/
  orderNetWorkBlock:function(handlerBlock){

        var urlStr = "http://192.168.210.151:8080/ECommercePlatform/m/orderV602/queryOrderList"
        var publicParamsType = NSNumber.numberWithInteger(0)
        var pageNo = "1"
        var pageRange = "5"
        var payFlag = "1"

        var tempParams = NSMutableDictionary.dictionary()
        tempParams.setValue_forKey(pageNo,"pageNo")
        tempParams.setValue_forKey(pageRange,"pageRange")
        tempParams.setValue_forKey(payFlag,"payFlag")

        var arguments = CHNetworkArguments.alloc().init()
        arguments.setUrl(urlStr)
        arguments.setPublicParamsType(publicParamsType)
        arguments.setParams(tempParams)
        arguments.setScretType(NSNumber.numberWithInteger(2));

        CHCommonNetworkEngine.commonNetworkRequest_callBack(arguments,block("id,id",function(successInfo, errorInfo){

            if (errorInfo) {
                console.log(errorInfo)
            }else{
                if (successInfo && successInfo.isKindOfClass(NSDictionary.class()) && successInfo.count()>0) {

                  var ifSuccess = successInfo.valueForKey("ifSuccess")
                  if (ifSuccess.isEqualToString("Y")) {

                      handlerBlock(successInfo,null);
                }
            }else{
                handlerBlock(null,"CHNetworkDataFormatError");
            }

          }
     }));

  }

});







































