

/*UIKit*/
require('UIColor,UITableView,UIViewController,UITableViewCell,UIScreen,UIFont')

require('JSPatchViewController')

defineClass("CHTestViewController:UIViewController<UITableViewDataSource,UITableViewDelegate>",["customTableView"],{
	viewDidLoad:function() { 
    	self.super().viewDidLoad();
    	self.view().setBackgroundColor(UIColor.orangeColor())

		var windowWidth = UIScreen.mainScreen().bounds().width
		var windowHeight = UIScreen.mainScreen().bounds().height

        var orderTableView = UITableView.alloc().initWithFrame_style({x:0, y:0, width:windowWidth, height:windowHeight-64},0)

        self.setCustomTableView(orderTableView)

       	self.customTableView().setDelegate(self)
        self.customTableView().setDataSource(self)

        self.view().addSubview(self.customTableView());
   },

   tableView_numberOfRowsInSection:function(tableView,section){
   	  return UIFont.familyNames().count();
   },

   tableView_cellForRowAtIndexPath:function(tableView,indexPath){
   	  var identify = "identify"
   	  var cell = tableView.dequeueReusableCellWithIdentifier(identify)
   	  if (!cell) {
   		 cell = UITableViewCell.alloc().initWithStyle_reuseIdentifier(0,identify)
   	  };

      var fontStr = UIFont.familyNames().objectAtIndex(indexPath.row())
            
      var font = UIFont.fontWithName_size(fontStr,24)
      cell.textLabel().setFont(font)
      cell.textLabel().setText(fontStr)
      return cell;
   },

  tableView_heightForRowAtIndexPath: function(tableView, indexPath) {
    return 60
  },

  tableView_didSelectRowAtIndexPath: function(tableView, indexPath) {
        var fontStr = UIFont.familyNames().objectAtIndex(indexPath.row())
        console.log(fontStr)
        var patchViewController = JSPatchViewController.alloc().init()
        self.navigationController().pushViewController_animated(patchViewController,1)
  },
})