

require('NSArray,NSBundle,NSDictionary,NSMutableArray,NSNumber')
/*UIKit*/
require('UIColor,UITableView,MyNavigationViewController,UITableViewCell,UIScreen,UIFont')

require('JSPatchNetwork,JSPatchCell')

defineClass("JSPatchViewController:MyNavigationViewController<UITableViewDataSource,UITableViewDelegate>",["customTableView","orderList"],{

	viewDidLoad:function() { 
      self.super().viewDidLoad();
      self.setTitle("订单列表")

      self.view().setBackgroundColor(UIColor.orangeColor())
      self.setEdgesForExtendedLayout(0)
      
      var windowWidth = UIScreen.mainScreen().bounds().width
      var windowHeight = UIScreen.mainScreen().bounds().height
      var orderTableView = UITableView.alloc().initWithFrame_style({x:0, y:0, width:windowWidth, height:windowHeight-64},0)

      orderTableView.setDelegate(self)
      orderTableView.setDataSource(self)

      self.view().addSubview(orderTableView);

      self.setOrderList(NSArray.array())
      self.setCustomTableView(orderTableView)

     self.orderNetWorkBlock()
   },

/*****************UITableViewDataSource*********************/
   tableView_numberOfRowsInSection:function(tableView,section){
      
      return self.orderList().count()
   },

   tableView_cellForRowAtIndexPath:function(tableView,indexPath){

      var identify = "identify"
      var cell = tableView.dequeueReusableCellWithIdentifier(identify)
      if (!cell) {
         cell = JSPatchCell.alloc().initWithStyle_reuseIdentifier(3,identify)
      };

      var model = self.orderList().objectAtIndex(indexPath.row())
      cell.configCellWithData(model);

      return cell;
   },

  tableView_heightForRowAtIndexPath: function(tableView, indexPath) {
    return 120
  },

/*****************UITableViewDelegate*********************/
  tableView_didSelectRowAtIndexPath: function(tableView, indexPath) {
        var fontStr = self.orderList().objectAtIndex(indexPath.row())
        console.log(fontStr)
  },

/*****************事件处理*********************/


/*****************网络层*********************/
   orderNetWorkBlock:function(){

      
      var params = NSMutableDictionary.dictionary()
      var tempParams = NSMutableDictionary.dictionary()
      tempParams.setValue_forKey(pageNo,"pageNo")
      tempParams.setValue_forKey(pageRange,"pageRange")
      tempParams.setValue_forKey(payFlag,"payFlag")

      var weakSelf = __weak(self)
      var patchNetwork = JSPatchNetwork.alloc().init()
      // patchNetwork.test()
     //  patchNetwork.orderNetWorkBlock(tempParams,block("id,id",function(successInfo, errorInfo){

     //        if (errorInfo) {
     //            handleBlock(null,errorInfo)
     //        }else{              
     //            setself.setOrderList(successInfo)
     //            weakSelf.customTableView().reloadData()
     //        }
     // }));
   }
});