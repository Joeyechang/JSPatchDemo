//
//  CHTestViewController.h
//  Spring3G
//
//  Created by CY-100 on 16/5/16.
//  Copyright © 2016年 SpringAirlines. All rights reserved.
//

#import "MyNavigationViewController.h"

@interface CHTestViewController : MyNavigationViewController

@end
