

defineClass("JSPatchModel:NSObject",["orderDate","orderMoneyDisplay","orderNo","orderStatusDescript","originDestCity"],{

  initWithDictionary:function(dict){

    if(self = self.super().init()){
        self.setOrderNo(dict.valueForKey("orderNo"))
        self.setOrderDate(dict.valueForKey("orderDate"))
        self.setOrderMoneyDisplay(dict.valueForKey("orderMoneyDisplay"))
        self.setOrderStatusDescript(dict.valueForKey("orderStatusDescript"))
        self.setOriginDestCity(dict.valueForKey("originDestCity"))
     }
    return self
  },
});