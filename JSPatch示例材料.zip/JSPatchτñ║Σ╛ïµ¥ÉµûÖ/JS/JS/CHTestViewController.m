//
//  CHTestViewController.m
//  Spring3G
//
//  Created by CY-100 on 16/5/16.
//  Copyright © 2016年 SpringAirlines. All rights reserved.
//

#import "CHTestViewController.h"
#import "JPEngine.h"

@implementation CHTestViewController

- (void)viewDidLoad{
    [super viewDidLoad];
}

- (void)loadJSPatch{
    
    [JPEngine startEngine];
    
    NSArray <NSString*>*jsArray = @[@"JSPatchMain",@"JSPatchViewController",@"JSPatchCell",@"JSPatchNetwork",@"JSPatchModel"];
    [jsArray enumerateObjectsUsingBlock:^(NSString * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSString *sourcePath = [[NSBundle mainBundle] pathForResource:obj ofType:@"js"];
        NSString *script = [NSString stringWithContentsOfFile:sourcePath encoding:NSUTF8StringEncoding error:nil];
        if (script) {
            [JPEngine evaluateScript:script];
        }
    }];
    
    /* 沙盒下面读取js文件
     NSString *filePath = [NSHomeDirectory() stringByAppendingString:@"/Documents/JSPatch"];
     NSArray *files = [[NSFileManager defaultManager] subpathsOfDirectoryAtPath:filePath error:nil];
     [files enumerateObjectsUsingBlock:^(NSString * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([obj hasSuffix:@".js"]) {
            NSString *sourcePath = [filePath stringByAppendingPathComponent:obj];
            NSString *script = [NSString stringWithContentsOfFile:sourcePath encoding:NSUTF8StringEncoding error:nil];
            if (script) {
                [JPEngine evaluateScript:script];
            }
        }
     }];*/
}

@end
