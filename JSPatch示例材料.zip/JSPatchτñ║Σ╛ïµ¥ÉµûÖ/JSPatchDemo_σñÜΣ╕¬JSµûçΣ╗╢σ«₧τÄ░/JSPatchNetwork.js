

require('NSArray,NSBundle,NSDictionary,NSMutableArray,NSNumber')
/*UIKit*/
require('CHCommonNetworkEngine,JSPatchModel,CHNetworkArguments')

defineClass("JSPatchNetwork:NSObject",{
  orderNetWorkBlock:function(params,handleBlock){

        // var urlStr = "http://192.168.210.151:8080/ECommercePlatform/m/orderV602/queryOrderList"
        // var publicParamsType = NSNumber.numberWithInteger(0)
        // var pageNo = "1"
        // var pageRange = "5"
        // var payFlag = "1"
        // var tempParams = NSMutableDictionary.dictionary()
        // tempParams.setValue_forKey(pageNo,"pageNo")
        // tempParams.setValue_forKey(pageRange,"pageRange")
        // tempParams.setValue_forKey(payFlag,"payFlag")

        var urlStr = "http://192.168.210.52:8092/ECommercePlatform/m/orderV602/queryOrderList"
        
        var arguments = CHNetworkArguments.alloc().init()
        arguments.setUrl(urlStr)
        arguments.setPublicParamsType(NSNumber.numberWithInteger(0))
        arguments.setParams(params)
        arguments.setScretType(NSNumber.numberWithInteger(2));

        var tempSelf = self;

        CHCommonNetworkEngine.commonNetworkRequest_callBack(arguments,block("id,id",function(successInfo, errorInfo){

            if (errorInfo) {
                  handleBlock(null,errorInfo)
            }else{                                                                    
                if (successInfo && successInfo.isKindOfClass(NSDictionary.class()) && successInfo.count()>0) {
                  var ifSuccess = successInfo.valueForKey("ifSuccess")
                  if (ifSuccess.isEqualToString("Y")) {
                     var tempList = NSMutableArray.array()
                    for (var i = 0; i < successInfo.valueForKey("orders").count(); i++) {
                        var order = JSPatchModel.alloc().initWithDictionary(successInfo.valueForKey("orders").objectAtIndex(i))
                        tempList.addObject(order)
                    };
                    handleBlock(tempList,null)
                  }else{
                    handleBlock(null,"网络请求失败")
                  }
              }
          }
     }));
  }
});