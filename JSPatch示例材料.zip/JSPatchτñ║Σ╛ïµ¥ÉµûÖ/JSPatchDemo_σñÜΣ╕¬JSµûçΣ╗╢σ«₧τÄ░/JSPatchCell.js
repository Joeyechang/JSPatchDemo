
require('UILabel,UIImageView,UIImage,UITableView')

defineClass("JSPatchCell:UITableViewCell",["city","num","timeText","money","pay"],{

  initWithStyle_reuseIdentifier:function(style,reuseIdentifier) {
    self = self.super().initWithStyle_reuseIdentifier(style,reuseIdentifier)
    if (self) {
      var windowWidth = UIScreen.mainScreen().bounds().width
      var windowHeight = UIScreen.mainScreen().bounds().height

      var labelNo = UILabel.alloc().initWithFrame({x:58, y:29, width:51, height:21})
      labelNo.setText("订单号")
      labelNo.setFont(UIFont.fontWithName_size("Helvetica",12))
      self.contentView().addSubview(labelNo)

      var labelTime = UILabel.alloc().initWithFrame({x:45, y:58, width:51, height:21})
      labelTime.setText("预定时间")
      labelTime.setFont(UIFont.fontWithName_size("Helvetica",12))
      self.contentView().addSubview(labelTime)

      var labelMoney = UILabel.alloc().initWithFrame({x:45, y:87, width:51, height:21})
      labelMoney.setText("订单金额")
      labelMoney.setFont(UIFont.fontWithName_size("Helvetica",12))
      self.contentView().addSubview(labelMoney)

      var img = UIImageView.alloc().initWithFrame({x:330, y:53, width:10, height:30})
      img.setImage(UIImage.imageNamed("arrow_right_v600"))
      self.contentView().addSubview(img)

      var c = UILabel.alloc().initWithFrame({x:0, y:0, width:windowWidth, height:21})
      c.setBackgroundColor(UIColor.grayColor())
      c.setFont(UIFont.boldSystemFontOfSize(14.0))//加粗字体及大小
      c.setTextAlignment(1)//居中
      self.setCity(c)
      self.contentView().addSubview(self.city())

      var n = UILabel.alloc().initWithFrame({x:111, y:29, width:93, height:21})
      n.setFont(UIFont.fontWithName_size("Helvetica",12))
      self.setNum(n)
      self.contentView().addSubview(self.num())

      var t = UILabel.alloc().initWithFrame({x:111, y:58, width:134, height:21})
      t.setFont(UIFont.fontWithName_size("Helvetica",12))
      self.setTimeText(t)
      self.contentView().addSubview(self.timeText())

      var m = UILabel.alloc().initWithFrame({x:111, y:87, width:61, height:21})
      m.setTextColor(UIColor.redColor())
      m.setFont(UIFont.fontWithName_size("Helvetica",12))
      self.setMoney(m)
      self.contentView().addSubview(self.money())

      var p = UILabel.alloc().initWithFrame({x:280, y:58, width:60, height:21})
      p.setFont(UIFont.fontWithName_size("Helvetica",12))
      self.setPay(p)
      self.contentView().addSubview(self.pay())

    };
    return self
  },
  
  configCellWithData:function(data){
    
    self.city().setText(data.originDestCity())
    self.num().setText(data.orderNo())
    self.timeText().setText(data.orderDate())
    self.money().setText(data.orderMoneyDisplay())
    self.pay().setText(data.orderStatusDescript())
  }

});